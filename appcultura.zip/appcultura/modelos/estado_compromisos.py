from django.db import models

class EstadoCompromisos(models.Model):
    descripcion = models.TextField()